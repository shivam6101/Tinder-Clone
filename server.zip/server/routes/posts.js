const express=require("express");
//const { Mongoose } = require("mongoose");
const router=express.Router()
const mongoose = require("mongoose")
const requirelogin=require("../middleware/loginrequire")
const Post=mongoose.model("post")

router.get("/allposts",requirelogin,(req,res)=>{
    Post.find()
    .populate("postedby","_id name")
    .then(Post=>{
        res.json(Post)
    })
    .catch(err=>{
        res.json(err)
    })
})
router.get('/myposts',requirelogin,(req,res)=>{
    Post.find({postedby:req.user._id})
    .populate("postedby","_id name")
    .then(mypost=>{
        res.json(mypost)
    })
    .catch(err=>{
        console.log(err)
    })
})

router.post('/createpost',requirelogin,(req,res)=>{
    const {title,body}=req.body
    if(!title || !body){
        res.status(422).json({error:"add all fields"})
    }
    req.user.password=undefined
    const post=new Post({
        title,
        body,
        postedby:req.user
    })
    post.save()
    .then(result=>{
        res.json({post:result})
    })
    .catch(err=>{
        res.json(err)

    })
})
module.exports=router