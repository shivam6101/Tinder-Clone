import React from "react";
import Students from "./Students";
import Header from "./Header";
import Tindercards from "./Tindercards";
import Swipebutttons from "./Swipebuttons";
function App(){
  return (
    <div className="app">
      <Header />
      <Tindercards />
      <Swipebutttons />
    </div>
  )
}

export default App;