import React,{useState,useEffect} from 'react';
import TinderCard from "react-tinder-card";
import "./tindercards.css";
import axios from "./axios"
function Tindercards() {
    const [people,setpeople]= useState([]);
    
    useEffect(() => {
        async function fetchdata(){
            const req=await axios.get("/tinder/card");

            setpeople(req.data)
        }
        fetchdata();
    },[]);

    const swiped=(direction,nametdelete) => {
        console.log("removing"+nametdelete)
    }
    const outOfFrame=(name) => {
        console.log(name+"left to screen")
    }
    return (
        <div className="tindercards">
            <div className="tindercard_cardcontainer">
                { people.map((person) => (
                    <TinderCard 
                        className="swipe"
                        key={person.name}
                        preventSwipe={["up","down"]}
                        onSwipe={(dir) => swiped(dir,person.name)}
                        onCardLeftScreen={()=> outOfFrame(person.name)}
                        >
                            <div 
                                style={{backgroundImage:`url(${person.url})`}}
                                className="card">
                                    <h3>{person.name}</h3>
                            </div>
                    </TinderCard>
                ))}
            </div>
        </div>
    )
}

export default Tindercards