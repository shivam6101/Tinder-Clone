import React, { Component } from "react";
import "./Students.css"
import "./App.css"
class Students extends Component {
        state= {
            name:"rahi",
            rollno:this.props.rollno
        }
    eventhandle =() => {
        this.setState({name:"jai",rollno:"105"})
    };
    render() {
        return (
            <div>
                <h1 className="new">hello {this.state.name} roll no {this.state.rollno}</h1>
                <button onClick={this.eventhandle}>click me</button>
            </div>
        )
    }
}

export default Students;