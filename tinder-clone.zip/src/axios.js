import axios from "axios"

const instance=axios.create({
    baseURL:'https://tinder-backend-sem.herokuapp.com',
})

export default instance;